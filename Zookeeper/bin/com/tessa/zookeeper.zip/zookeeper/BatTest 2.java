package com.tessa.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		System.out.println("hello");
		
		Bat myBat = new Bat();

	}

}

package com.tessa.zookeeper;

public class Bat {
	
	public Bat() {
		
	}
}

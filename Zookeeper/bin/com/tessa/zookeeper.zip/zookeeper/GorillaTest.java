package com.tessa.zookeeper;

public class GorillaTest {
	
	public static void main(String[] args) {
	
	Gorilla oneGorilla = new Gorilla();
	
	oneGorilla.throwSomething();
	oneGorilla.throwSomething();
	oneGorilla.throwSomething();
	oneGorilla.eatBananas();
	oneGorilla.eatBananas();
	oneGorilla.climb();
	oneGorilla.displayEnergy();
	

	}
}